function cambiarTitulo() {
    document.getElementById("titulo").innerText = "¡Kick Buttowski - Leyenda de Mellowbrook!";
}

function agrandarImagen() {
    document.getElementById("foto").style.width = "260px";
}

function regresarImagen() {
    document.getElementById("foto").style.width = "200px";
}

function cambiarColorTexto() {
    document.getElementById("contenido").style.color = "#e65100";
}

function bienvenida() {
    alert("Bienvenido a la pagina de Kick Buttowski");
}

function llamarMiPagina1() {
    window.location.href = "pagina1.html";
}